package Teste;

import modelo.Venda;
import modelo.VendaDAO;

import java.util.List;

public class Teste {
    public static void main(String[] args) {
        VendaDAO vendaDAO = new VendaDAO();

        Venda venda = new Venda(64L,"D",500.0);
        vendaDAO.inserir(venda);

        List<Venda> lista = vendaDAO.listar();
        for (Venda v: lista){
            System.out.println("ID: "+v.getId()+" Vendedor: "+v.getVendedor()+" Valor: "+v.getValor());
        }

        System.out.println("");
        vendaDAO.valorTotal();
        vendaDAO.nomeVendedor();
    }
}
