package modelo;

import conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class VendaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private Conexao conexao;

    public VendaDAO() {
        this.conexao = conexao;
    }

    public void inserir(Venda venda){
        String sql = "INSERT INTO java_venda VALUES(?,?,?)";
        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            ps.setLong(1,venda.getId());
            ps.setString(2, venda.getVendedor());
            ps.setDouble(3,venda.getValor());
            ps.execute();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir venda\n"+e);;
        }
    }

    public List<Venda> listar(){
        List<Venda> lista = new ArrayList<>();
        String sql = "select * from java_venda";
        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()){
                lista.add(new Venda(rs.getLong("id"),rs.getString("vendedor"),rs.getDouble("valor")));
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar venda\n"+e);;
        }
        return lista;
    }

    public void valorTotal(){
        List<Venda> lista = new ArrayList<>();
        String sql = "select * from java_venda";
        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            double total=0;
            while (rs.next()){
                lista.add(new Venda(rs.getLong("id"),rs.getString("vendedor"),rs.getDouble("valor")));
                total+= rs.getDouble("valor");
            }
            System.out.println("Total de vendas: "+total);
        } catch (SQLException e) {
            System.out.println("Erro ao mostrar total\n"+e);;
        }
    }

    public void nomeVendedor(){
        List<Venda> lista = new ArrayList<>();
        String sql = "select * from java_venda";
        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            String nome="";
            while (rs.next()){
                lista.add(new Venda(rs.getLong("id"),rs.getString("vendedor"),rs.getDouble("valor")));
                lista.sort(Comparator.comparing(Venda::getValor));
                nome = rs.getString("vendedor");
            }
            System.out.println("Nome do vendedor que recebeu a maior venda: "+nome);
        } catch (SQLException e) {
            System.out.println("Erro ao mostrar nome do vendedor com maior venda\n"+e);;
        }
    }
}
