import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Venda> vendas = new ArrayList<>();
        Venda venda = new Venda(55, "Silvio", 5000);
        //venda = new Venda(55, "Silvio", 5000);
        vendas.add(venda);
        VendaDAO vendaDAO = new VendaDAO();

        // 1. Insira registros do tipo Venda na tabela java_venda
        vendaDAO.inserir(venda);

        // 2. Liste todos os dados armazenados na tabela java_venda
        vendas = vendaDAO.listar();
        vendas.forEach(System.out::println);

        // 3. Imprima o valor total das vendas (soma de todos os valores)
        vendas = vendaDAO.listar();
        double total = 0;
        for (Venda v : vendas) {
            total += v.getValor();
        }
        System.out.println("Valor total em vendas: R$"+total);

        // 4. Imprima o nome do vendedor que realizou a maior venda. Caso dois ou mais vendedores estejam empatados, imprima o nome de todos.
        vendas = vendaDAO.listar();
        vendas.sort(Comparator.comparing(Venda::getValor).reversed());
        for(int i = 0; i < vendas.size(); i++){
            if (vendas.get(0).getValor() == vendas.get(i).getValor()){
                System.out.println(vendas.get(i).getVendedor());
            }
        }
    }
}
