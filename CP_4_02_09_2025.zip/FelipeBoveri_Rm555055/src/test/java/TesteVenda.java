import java.util.List;

public class TesteVenda {
    public static void main(String[] args) {
        VendaDAO dao = new VendaDAO();

        //LISTAR TODOS OS ITENS DA TABELA
        List<Venda> lista = dao.listar();
        for(Venda venda : lista){
            System.out.println(venda.getId());
            System.out.println(venda.getVendedor());
            System.out.println(venda.getValor());
            System.out.println();
        }
    }
}
