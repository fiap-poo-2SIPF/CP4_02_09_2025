package br.fiap;

import java.util.List;

public class TesteVenda {
    public static void main(String[] args) {
        VendaDao dao = new VendaDao();

        List<Venda> lista = dao.listar();
        for (Venda venda : lista) {
            System.out.println(venda.getId());
            System.out.println(venda.getVendedor());
            System.out.println("R$ " + venda.getValor());
            System.out.println();
        }
    }
}
