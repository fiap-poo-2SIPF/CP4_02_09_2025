package br.fiap;

public class Venda {
    private Long id;
    private String vendedor;
    private double valor;

    public Venda(Long id, String vendedor, double valor) {
        this.id = id;
        this.vendedor = vendedor;
        this.valor = valor;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVendedor() {
        return vendedor;
    }

    public void setVendedor(String vendedor) {
        this.vendedor = vendedor;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
