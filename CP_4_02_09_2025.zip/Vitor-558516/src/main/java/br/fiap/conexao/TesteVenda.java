package br.fiap.conexao;

import java.util.List;

public class TesteVenda {
    public static void main(String[] args) {
        VendaDAO dao = new VendaDAO();

        List<Venda> lista = dao.listar();
        for(Venda venda : lista) {
            System.out.println(venda.getId());
            System.out.println(venda.getVendedor());
            System.out.println("R$ " + venda.getValor());
            System.out.println();
        }

        List<Venda> lista = dao.relatorio();
        for (Venda venda : lista) {
            System.out.println(venda.getId());
            System.out.println(venda.getVendedor());
            System.out.println("R$ " + venda.getValor());
            System.out.println();
        }
    }
}
