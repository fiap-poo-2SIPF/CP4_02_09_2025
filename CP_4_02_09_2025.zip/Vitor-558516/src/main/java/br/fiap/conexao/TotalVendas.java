package br.fiap.conexao;

public class TotalVendas {
    public static void main(String[] args) {
        double venda1 = "85.10";
        double venda2 = "90.10";
        double venda3 = "75.10";

        double totalVendas = venda1 + venda2 + venda3;

        System.out.println("Valor total de venda: R$ ") + TotalVendas;
    }
}
