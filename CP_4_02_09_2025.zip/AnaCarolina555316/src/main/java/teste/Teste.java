package teste;

import modelo.Venda;
import modelo.VendaDAO;

import java.util.List;

public class Teste {
    public static void main(String[] args) {
        VendaDAO dao = new VendaDAO();

        //inserir
        Venda v1 = new Venda();
        v1.setId(1L);
        v1.setVendedor("Joao");
        v1.setValor(500);
        dao.inserir(v1);

        Venda v2 = new Venda();
        v2.setId(2L);
        v2.setVendedor("Bruno");
        v2.setValor(300);
        dao.inserir(v2);

        Venda v3 = new Venda();
        v3.setId(3L);
        v3.setVendedor("Paulo");
        v3.setValor(500);
        dao.inserir(v3);

        Venda v4 = new Venda();
        v4.setId(4L);
        v4.setVendedor("Lucas");
        v4.setValor(100);
        dao.inserir(v4);

        Venda v5 = new Venda();
        v5.setId(4L);
        v5.setVendedor("Lucas");
        v5.setValor(100);
        dao.inserir(v4);

        //listar
        System.out.println("");
        List<Venda> lista = dao.listar();
        for(Venda venda :lista) {
            System.out.println(venda.getId() +" - "+venda.getVendedor());
            System.out.println("R$ "+ venda.getValor());
            System.out.println("");
        }

        //somar
        System.out.println("");
        System.out.println("A soma total das vendas é de R$ "+dao.somarValor());

        //nomes maior venda
        System.out.println("");
        System.out.println("--- Vendedores com maiores vendas ---");
        System.out.println(dao.maiorVenda());

    }
}
