package modelo;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    public void inserir(Venda venda) {
        sql = "insert into java_venda values (?,?,?)";
        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setLong(1, venda.getId());
            ps.setString(2, venda.getVendedor());
            ps.setDouble(3, venda.getValor());
            ps.execute();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir venda\n + e");
        }
    }
    public List<Venda> listar() {
        List<Venda> lista = new ArrayList<>();
        sql = "select * from java_venda";
        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Venda venda = new Venda();
                venda.setId(rs.getLong("id"));
                venda.setVendedor(rs.getString("vendedor"));
                venda.setValor(rs.getDouble("valor"));
                lista.add(venda);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao inserir venda\n + e");
        }
        return lista;
    }

    public double somarValor() {
        double soma = 0;
        List<Venda> lista = listar();
        for(Venda venda :lista) {
            soma+= venda.getValor();
        }

        return soma;
    }

    public String maiorVenda() {
        String nomes_maiorVenda = "";
        double maiorVenda = 0;
        List<Venda> lista = listar();
        for(Venda venda :lista) {
            if (venda.getValor() > maiorVenda) {
                maiorVenda = venda.getValor();
                nomes_maiorVenda = venda.getVendedor()+"\n";
            } else if (venda.getValor() == maiorVenda) {
                nomes_maiorVenda += venda.getVendedor()+"\n";
            }
        }
        return nomes_maiorVenda;
    }

}
