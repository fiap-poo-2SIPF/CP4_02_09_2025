package Projeto;

public class Venda {
    private int id;
    private String vendedor;
    private double valor;

    public Venda(int id, String vendedor, double valor) {
        this.id = id;
        this.vendedor = vendedor;
        this.valor = valor;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVendedor() {
        return vendedor;
    }

    public void setVendedor(String vendedor) {
        this.vendedor = vendedor;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
