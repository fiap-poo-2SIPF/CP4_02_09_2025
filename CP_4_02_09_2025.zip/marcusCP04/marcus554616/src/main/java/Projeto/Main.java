package Projeto;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        VendaDAO dao=new VendaDAO();
        List<Venda>list=new ArrayList<>();




        Venda venda=new Venda(25,"joao",10);
        dao.inserir(venda);

        list=dao.listar();


        for (Venda e:list){
            System.out.println(e.getId()+ " || "+e.getVendedor()+" || "+e.getValor());
            System.out.println();
        }

        System.out.println("valor total das vendas"+dao.soma());
        
        Comparator<Venda>criterio= Comparator.comparing(Venda::getValor);

        list.sort(criterio);

        list.forEach(vend -> System.out.println(venda.getVendedor()));


    }


}

