package Projeto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;
    private Conexao conexao;


    public VendaDAO() {
        this.conexao = new Conexao();
    }

    public void inserir(Venda venda){
        sql="INSERT INTO java_venda VALUES (?,?,?)";

        try(Connection connection=conexao.conectar()) {
            ps=connection.prepareStatement(sql);
            ps.setInt(1,venda.getId());
            ps.setString(2,venda.getVendedor());
            ps.setDouble(3,venda.getValor());

            ps.execute();

        }catch (SQLException e){
            System.out.printf("nao foi possivel inserir "+e.getMessage());
        }
    }

    public List<Venda>listar(){
        List<Venda>lista=new ArrayList<>();
        sql="SELECT * FROM java_venda";

        try(Connection connection=conexao.conectar()){
        ps=connection.prepareStatement(sql);
        rs= ps.executeQuery();

        while (rs.next()){

            lista.add(new Venda(rs.getInt("id"),
                    rs.getString("vendedor"),
                    rs.getInt("valor")));
        }
        }catch (SQLException e) {
            System.out.println("nao foi possivel listar");
        }
        return lista;
    }

    public double soma(){
        double soma = 0;
        List<Venda>lista=new ArrayList<>();
        sql="SELECT * FROM java_venda";

        try(Connection connection=conexao.conectar()){
            ps=connection.prepareStatement(sql);
            rs= ps.executeQuery();

            while (rs.next()){
                soma+=rs.getDouble("valor");
            }
        }catch (SQLException e) {
            System.out.println("nao foi possivel somar");
        }

        return soma;
    }
}
