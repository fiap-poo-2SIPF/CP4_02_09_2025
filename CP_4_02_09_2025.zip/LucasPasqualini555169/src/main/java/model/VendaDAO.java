package model;

import main.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    public void inserir(Venda venda) {
        sql = "INSERT INTO java_venda VALUES (?,?,?)";
        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setLong(1,venda.getId());
            ps.setString(2,venda.getVendedor());
            ps.setDouble(3,venda.getValor());
            ps.execute();

        } catch (SQLException e) {
            System.out.println("Erro ao inserir venda, erro: " + e + " , código do erro: " + e.getErrorCode());
        }
    }

    public List<Venda> listar() {
        List<Venda> lista = new ArrayList<>();
        sql = "SELECT * FROM java_venda";

        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Venda venda = new Venda(
                        rs.getLong("id"),
                        rs.getString("vendedor"),
                        rs.getDouble("valor")
                );
                lista.add(venda);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar venda, erro: " + e + " , código do erro: " + e.getErrorCode());
        }
        return lista;
    }
}
