package main;

import model.Venda;
import model.VendaDAO;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        double total = 0;
        List<Venda> vendas = new ArrayList<>();
        VendaDAO vendaDAO = new VendaDAO();
        Venda venda = new Venda(34,"C",3.0);

        //1
        vendaDAO.inserir(venda);

        //2
        vendas = vendaDAO.listar();
        vendas.forEach(System.out::println);

        //3
        vendas = vendaDAO.listar();
        for(Venda v : vendas) {
            total += v.getValor();
        }
        System.out.println("Total em vendas: " + total);

        //4
        vendas = vendaDAO.listar();
        vendas.sort(Comparator.comparing(Venda::getValor)
                .reversed());

        System.out.println("Vendedores com maiores vendas: ");
        for (int i = 0; i < vendas.size(); i++) {
            if(vendas.get(0).getValor() == vendas.get(i).getValor()){
                System.out.println(vendas.get(i).getVendedor());
            }
        }
    }
}
