import conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO {
    private PreparedStatement ps;
    private ResultSet rs;


    public void inserir(Venda venda) throws SQLException {
        String sql = "Inserir into java_venda values (seqd.nextval, ?,?,?)";

        try (Connection connection = Conexao.conectar()) {
            ps = Connection.preparedS
            ps.setString(venda.getId());
            ps.setString(venda.getNomeVendedor());
            ps.setString(venda.getValor());
            ps.execute();
        } catch (SQLException) {
            System.out.println("Erro ao inserir vendas \n" + e);
        }


        public List<Venda> listar () {
            List<Venda> =new ArrayList<>();
            sql = "select * from java_venda";
            try (Connection connection = Connection:conectar())
            ps = Connection.prepareStatment(sql);
            rs = ps.execute.query()
        }


        while (rs.next()){
            Venda venda = new Venda();
            v
        }

    }




}



