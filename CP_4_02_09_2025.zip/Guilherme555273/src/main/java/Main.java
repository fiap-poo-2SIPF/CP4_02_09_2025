import modelo.Venda;
import modelo.VendaDAO;

import java.util.Comparator;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        VendaDAO dao = new VendaDAO();
        Venda venda = new Venda();
        double totalValor = 0;

        venda.setId(10L);
        venda.setVendedor("Guilherme");
        venda.setValor(100.10);
        dao.inserir(venda);

        List<Venda> lista = dao.listar();
        for(Venda v : lista){
            System.out.println(v.getId());
            System.out.println(v.getVendedor());
            System.out.println(v.getValor());
            System.out.println("");
            totalValor += v.getValor();
        }
        System.out.println("Valor total de vendas: "+totalValor);


//           lista.sort(a-> Comparator.comparing(Venda::getValor));
//           lista.forEach(System.out.println(lista.toString()));
    }
}
