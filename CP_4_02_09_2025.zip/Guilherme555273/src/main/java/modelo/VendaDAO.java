package modelo;
import conexao.Conexao;

import javax.xml.transform.Result;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class VendaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    public void inserir (Venda venda){
        sql = "insert into java_despesa values (?,?,?)";
        try(Connection connection = Conexao.conectar()){
            ps=connection.prepareStatement(sql);
            ps.setLong(1,venda.getId());
            ps.setString(2,venda.getVendedor());
            ps.setDouble(3,venda.getValor());
            ps.execute();
        }catch (SQLException e){
            System.out.println("Erro ao inserir venda: "+e.getMessage());
        }
    }

    public List<Venda> listar(){
        List<Venda> lista = new ArrayList<>();
        sql = "select * from java_venda";

        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Venda venda = new Venda();
                venda.setId(rs.getLong("id"));
                venda.setVendedor(rs.getString("vendedor"));
                venda.setValor(rs.getDouble("valor"));
                lista.add(venda);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar vendas" +e.getMessage());
        }

        return lista;
    }
}
