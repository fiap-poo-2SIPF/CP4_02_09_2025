public class Vendas {
    public String id;
    public String vendedor;
    public String valor;

    public Vendas(String valor, String vendedor, String id) {
        this.valor = valor;
        this.vendedor = vendedor;
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVendedor() {
        return vendedor;
    }

    public void setVendedor(String vendedor) {
        this.vendedor = vendedor;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
}
