import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class VendasDAO {
    private PreparedStatement ps;
    private ResultSet rs;

    public void inserir(Vendas vendas){
        String sql = "INSERT INTO java_venda VALUES(seqg.nextval, ?, ?, ?)";
        try(Connection connection = Conexao.conectar()){
           ps = connection.prepareStatement(sql);
           ps.setString(1, vendas.id);
           ps.setString(2, vendas.valor);
           ps.setString(3, vendas.vendedor);
           ps.execute();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir: " + e + "código: " + e.getErrorCode());
        }
    }

    public List<Vendas> listar(){
        List<Vendas> lista =  new ArrayList<>();
        String sql = "SELECT * from java_venda";
        try (Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Vendas vendas = new Vendas();
                vendas.setId(rs.getString("id"));
                vendas.setVendedor(rs.getString("nome"));
                vendas.setValor(rs.getString("valor"));
                lista.add(vendas);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar: "+ e.getErrorCode());
        };
        return lista;
    }
    
    public List<Vendas> relatorio(){
        List<Vendas> relatorio =  new ArrayList<>();
        
        relatorio.add(new Vendas("10", "joao", "20"));
        relatorio.add(new Vendas("20", "gabriel", "50"));
        relatorio.add(new Vendas("30", "antonio", "35"));
        
        relatorio.forEach(System.out::println);
        relatorio.sort(Comparator.comparing(Vendas::getVendedor).thenComparing(Vendas::getValor).thenComparing(Vendas::getId));

        System.out.println("\n----------------------------------------------------------------");
        relatorio.forEach(System.out::println);
    }

}
