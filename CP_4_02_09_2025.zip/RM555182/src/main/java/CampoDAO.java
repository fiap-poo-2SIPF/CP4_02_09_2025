import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CampoDAO {

    private PreparedStatement ps;
    private ResultSet rs;
    private Conexao conexao;

    public CampoDAO () {
        this.conexao = new Conexao();
    }

    public void inserir (Campo campo) {
        String sql = "insert into java_venda values (seqc.nextval, ?)";
        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);

            ps.setLong(1, campo.getId());
            ps.setLong(2, campo.getVendedor());
            ps.setLong(3, (long) campo.getValor());

            ps.execute();

        }
        catch (SQLException e) {
            System.out.println("Erro ao inserir campo\n + e");
        }

    }

    public List<Campo> listar() {
        List<Campo> lista = new ArrayList<>();
        String sql = "select * from java_venda";

        try (Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                lista.add (
                        new Campo (
                                rs.getLong("id_campo"),
                                rs.getString("campo")
                        )
                );
            }

        }
        catch (SQLException e) {
            System.out.println("Erro ao listar categoria\n " + e);
        }
        return lista;
    }


}//class
