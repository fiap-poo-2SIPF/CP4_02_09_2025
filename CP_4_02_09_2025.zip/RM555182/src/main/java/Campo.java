public class Campo {

    private Long id;
    private int vendedor;
    private double valor;

    public Campo(Long id, int vendedor, double valor) {
        this.id = id;
        this.vendedor = vendedor;
        this.valor = valor;

    }

    public Campo(long idCampo, String campo) {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getVendedor() {
        return vendedor;
    }

    public void setVendedor(int vendedor) {
        this.vendedor = vendedor;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }


}//class
