public class Venda {

    public String vendas = "Apartamento" + "Casa" + "Studio" + "Duplex";

}
