public class Venda {

    private long id;
    private String vendedor;
    private double valor;

    public Venda(long id, String vendedor, double valor) {
        this.id = id;
        this.vendedor = vendedor;
        this.valor = valor;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getVendedor() {
        return vendedor;
    }

    public void setVendedor(String vendedor) {
        this.vendedor = vendedor;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
