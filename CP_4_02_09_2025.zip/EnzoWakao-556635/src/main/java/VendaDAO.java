import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO {

    private PreparedStatement ps;
    private ResultSet rs;
    private Conexao conexao;

    public void inserir(Venda venda) {

        String sql = "insert into java_venda values (?, ?, ?)";

        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setLong(1, venda.getId());
            ps.setString(2, venda.getVendedor());
            ps.setDouble(3, venda.getValor());
            ps.execute();
        }
        catch (SQLException e) {
            System.out.println("Erro ao inserir venda");
        }

    }

    public List<Venda> listar() {

        List<Venda> lista = new ArrayList<>();

        String sql = "select * from java_venda";

        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()) {
                lista.add(new Venda(rs.getLong("id"), rs.getString("vendedor"),
                        rs.getDouble("valor")));
            }
        }
        catch (SQLException e) {
            System.out.println("Erro ao listar venda");
        }

        return lista;

    }

    public double totalVendas() {

        double total = 0;

        String sql = "select * from java_venda";

        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()) {
               total += rs.getDouble("valor");
            }
        }
        catch (SQLException e) {
            System.out.println("Erro ao listar venda");
        }

        return total;
    }

//    public String maiorVenda() {
//
//        String maiorVendedor = "";
//        double valor1 = 0;
//        double valor2 = 0;
//
//        String sql = "select * from java_venda";
//
//        try(Connection connection = Conexao.conectar()) {
//            ps = connection.prepareStatement(sql);
//            rs = ps.executeQuery();
//            while(rs.next()) {
//                valor1 = rs.getDouble("valor");
//                if(valor1 > ) {
//                    maiorVendedor = rs.getString("vendedor");
//                }
//            }
//        }
//        catch (SQLException e) {
//            System.out.println("Erro ao listar venda");
//        }
//
//        return maiorVendedor;
//
//    }

}
