import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        VendaDAO dao = new VendaDAO();

         //Exercicio 1 - Insira registros do tipo Venda na tabela java_venda
        dao.inserir(new Venda(6L, "Mario", 12.50));
        dao.inserir(new Venda(7L, "Marcio", 25.70));
        dao.inserir(new Venda(8L, "Enzo", 48.90));

        //Exercicio 2 - Liste todos os dados armazenados na tabela java_venda
        List<Venda> lista = dao.listar();

        for (Venda venda : lista) {
            System.out.println(venda.getId());
            System.out.println(venda.getVendedor());
            System.out.println("R$" + venda.getValor());
            System.out.println();
        }

        //Exercicio 3 - Imprima o valor total das vendas (soma de todos os valores)
        System.out.println("Total de vendas: R$" + dao.totalVendas());

        //Exercicio 4 - Imprima o nome do vendedor que realizou a maior venda

    }

}
