package br.fiap.modelo;

import br.fiap.conexao.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private Conexao conexao;
    private Connection connection;

    public VendaDAO() {
        this.conexao = new Conexao();
        this.connection = conexao.conectar();
    }

    public void inserir(Venda venda) {
        String sql = "insert into java_venda values(?, ?, ?)";
        try(Connection connection = conexao.conectar()){
            ps = connection.prepareStatement(sql);
            ps.setLong(1, venda.getId());
            ps.setString(2, venda.getVendedor());
            ps.setDouble(3, venda.getValor());
            ps.execute();
        } catch (SQLException e){
            System.out.println("Erro ao inserir categoria\n" +
                    e.getMessage());
        }
    }

    public List<Venda> relatorio(){
        List<Venda> lista = new ArrayList<>();

        String sql = "select v.id, v.vendedor, v.valor \n" +
                "from java_venda v \n";

        try(Connection connection = conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Venda venda = new Venda();
                venda.setId(rs.getLong("id"));
                venda.setVendedor(rs.getString("vendedor"));
                venda.setValor(rs.getDouble("valor"));

                lista.add(venda);
            }
        } catch(SQLException e){
            System.out.println("Erro ao gerar relatorio\n"+e.getMessage());
        }

        return lista;
    }

    public double totalVendas(){
        double total = 0;

        String sql = "select v.valor \n" +
                "from java_venda v \n";

        try(Connection connection = conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                double valor = rs.getDouble("valor");
                total += valor;
            }
        } catch(SQLException e){
            System.out.println("Erro ao obter vendas\n"+e.getMessage());
        }

        return total;
    }

    public String maiorVenda() {
        List<Venda> lista = new ArrayList<>();

        String sql = "select v.id, v.vendedor, v.valor \n" +
                "from java_venda v \n";

        try (Connection connection = conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Venda venda = new Venda();
                venda.setId(rs.getLong("id"));
                venda.setVendedor(rs.getString("vendedor"));
                venda.setValor(rs.getDouble("valor"));

                lista.add(venda);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao gerar relatorio\n" + e.getMessage());
        }

        Venda maiorVenda = lista.get(0);
        String vendedores = maiorVenda.getVendedor() + " | ";
        boolean empate = false;
        for (int i = 1; i < lista.size(); i++) {
            vendedores += lista.get(i).getVendedor() + " | ";

            if(lista.get(i).getValor() == maiorVenda.getValor()) {
                empate = true;
            }

            if(lista.get(i).getValor() > maiorVenda.getValor()) {
                maiorVenda = lista.get(i);
            }
        }

        if(!empate) {
            return maiorVenda.getVendedor();
        } else {
            return vendedores;
        }
    }
}
