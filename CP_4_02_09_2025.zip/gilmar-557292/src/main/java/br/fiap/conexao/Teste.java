package br.fiap.conexao;

import br.fiap.modelo.Venda;
import br.fiap.modelo.VendaDAO;

import java.util.List;

public class Teste {
    public static void main(String[] args) {
        VendaDAO dao = new VendaDAO();

//        teste para inserir
        Venda vendaTeste = new Venda();
        vendaTeste.setId(15L);
        vendaTeste.setVendedor("Reinaldo");
        vendaTeste.setValor(100.00);
        dao.inserir(vendaTeste);

        //teste para listar
        List lista = dao.relatorio();
        lista.forEach(v -> System.out.println(v));

        //teste para total de vendas
        System.out.println("Total de vendas: R$" + dao.totalVendas());

        // teste para maior venda
        System.out.println(dao.maiorVenda());
    }

}
