public class Teste {

Venda venda = new Venda();
VendaDAO vendaDAO = new VendaDAO();



}//class
