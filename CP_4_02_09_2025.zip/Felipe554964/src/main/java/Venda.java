public class Venda {
  String vendedor;
  double valor;
  Long id;
  String campo;


    public Venda() {
        this.vendedor = vendedor;
        this.valor = valor;
        this.id = id;
        this.campo = campo;
    }

    public String getVendedor() {
        return vendedor;
    }

    public void setVendedor(String vendedor) {
        this.vendedor = vendedor;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCampo() {
        return campo;
    }

    public void setCampo(String campo) {
        this.campo = campo;
    }
}//class
