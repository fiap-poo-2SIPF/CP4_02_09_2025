import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VendaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private Conexao conexao;
    private Connection connection;
String sql;

Venda venda = new Venda();

    public VendaDAO (){
        this.conexao = new Conexao();
        this.connection = conexao.conectar();
    }

    public void inserir (Venda venda){
         sql = "insert into java_venda values(?, ?, ?, ?)";

             try {
                 ps = connection.prepareStatement(sql);
                 ps.setString(1,"Nome do vendedor:");
                 ps.setString(1,"Nome do vendedor:");
                 ps.setString(1,"Joilson:");
                 ps.setDouble(2,80);
                 ps.execute();
             } catch (SQLException e) {
                 System.out.println("Erro ao inserir categoria\n "+ e);
             }

    }



}//class
