package br.fiap.modelo;

import br.fiap.conexao.Conexao;
import br.fiap.conexao.Venda;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VendaDaO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    //inserir
    public void inserir (Venda venda){
        sql = "insert into java_venda values (seqd.nextval,?,?,?)";
        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            //preenche os ? ? ?
            ps.setLong(1, venda.getId());
            ps.setString(2, venda.getVendedor());
            ps.setDouble(3, venda.getValor());
        }
        catch (SQLException e){
            System.out.println("Erro ao inserir venda \n"+ e);
        }

    }


    //listar
    public List<Venda> listar(){
        List<Venda> lista = new ArrayList<>();
        sql = "select * from java_venda";
        try(Connection connection = Conexao.conectar()){
            ps= connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while(rs.next()){
                Venda venda = new Venda();
                venda.setId(rs.getLong("id_venda"));
                venda.setVendedor(rs.getNString("nome_vendedor"));
                venda.setValor(rs.getDouble("valor"));
                lista.add(venda);
            }
        }catch (SQLException e){
            System.out.println("Erro ao listar venda \n"+ e);
        }


        return lista;
    }
}
