package br.fiap.modelo;

import br.fiap.conexao.Conexao;
import br.fiap.conexao.Venda;

import java.util.ArrayList;
import java.util.List;

public class Teste {
    public static void main(String[] args) {
        VendaDaO dao = new VendaDaO();
        Venda venda01 = new Venda();
        venda01.setId(100L);
        venda01.setVendedor("Lana");
        venda01.setValor(5000);
        dao.inserir(venda01);

        Venda venda02 = new Venda();
        venda01.setId(200L);
        venda01.setVendedor("Julia");
        venda01.setValor(5000);
        dao.inserir(venda02);
    }


}
