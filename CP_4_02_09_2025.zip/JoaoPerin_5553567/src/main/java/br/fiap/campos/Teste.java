package br.fiap.campos;

import java.util.ArrayList;
import java.util.List;

public class Teste {
    public static void main(String[] args) {
        VendaDAO vendaDAO = new VendaDAO();
        double valorTotal = 0;

        // 1. Inserir em java_venda
        Venda venda = new Venda(24, "Verissa", 9999.99);
        //vendaDAO.inserir(venda);

        //List<Venda> listaVendas = new ArrayList<>();

        //---------------------------------------------------------------------------------------------

        // 2. Listar tudo em java_venda
        System.out.println("----- Lista de Vendas -----");
        for (Venda l : vendaDAO.litar() ){
            System.out.println("ID: " + l.getId() + " | Vendedor: "+ l.getVendedor() + " | Valor: "+ l.getValor());
        }

        //---------------------------------------------------------------------------------------------

        // 3. Imprimir valor total vendas.
        for (Venda l : vendaDAO.litar() ){
            valorTotal += l.getValor();
        }
        System.out.println("\nValor total em vendas: " + valorTotal);

        //---------------------------------------------------------------------------------------------

        // 4. Imprimir nome vendedor com maior venda

        double maiorVenda = 0;
        String maiorVendedor = null;

        for (Venda l : vendaDAO.litar() ){

            if (l.getValor() > maiorVenda){
                maiorVenda = l.getValor();
                maiorVendedor = l.getVendedor();
            } else if (l.getValor() == maiorVenda){
                maiorVenda = l.getValor();
                maiorVendedor += " & " + l.getVendedor();
            }
        }
        System.out.println("\nVendedor com maior venda foi (" + maiorVendedor + ") com R$" + maiorVenda + " em vendas.");


    }
}
