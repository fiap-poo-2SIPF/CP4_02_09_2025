package br.fiap.campos;

import br.fiap.conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private Conexao conexao;

    public VendaDAO(){
        this.conexao = new Conexao();
    }

    public void inserir(Venda venda){
        String sql = "INSERT INTO java_venda VALUES (?,?,?)";

        try(Connection connection = conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setLong(1,venda.getId());
            ps.setString(2,venda.getVendedor());
            ps.setDouble(3,venda.getValor());
            ps.execute();
            System.out.println("Vendedor inserido.");
        }
        catch (SQLException e){
            System.out.println("Erro ao inserir venda\n"+e);
        }
    }

    public List<Venda> litar(){
        List<Venda> list = new ArrayList<>();
        String sql = "SELECT * from java_venda";

        try (Connection connection = conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()){
                list.add(new Venda(rs.getLong("id"),rs.getString("vendedor"),
                        rs.getDouble("valor")));
            }


        }
        catch (SQLException e) {
            System.out.println("Erro ao listar vendas\n"+e);
        }

        return list;
    }
}
