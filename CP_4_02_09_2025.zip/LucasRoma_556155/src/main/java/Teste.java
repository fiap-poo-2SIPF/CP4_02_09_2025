public class Teste {
    public static void main(String[] args) {
        VendaDAO vendaDAO = new VendaDAO();
        Venda venda = new Venda(22L, "B", 20.0);
        vendaDAO.inserir(venda);
        vendaDAO.listar();




    }
}
